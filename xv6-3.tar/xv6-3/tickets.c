#include "types.h"
#include "stat.h"
#include "user.h"
int
main(int argc, char *argv[])
{
  
  char* string_ticket = argv[1]; 
  int i = 0, ticket = 0;
  if((argv[1] == '\0') || (argv[2] == '\0'))
  {
	printf(1,"Missing arguments!! Please enter input in the form - tickets ticket_number process_name\n");
	exit();
  }
  for(i = 0;string_ticket[i] != '\0';i++)
  {
	int num = string_ticket[i]-'0';
        ticket = ticket * 10 + num;
  }
  //printf(1,"Number of tickets entered by user is %d\n",ticket);*/
  int ticket_op = settickets(ticket);
  if(ticket_op != 0)
	printf(1,"Error in ticket setting");
  char *ex[] = {argv[2],0};
  //printf(1,"The process you are going to schedule is %s\n",argv[2]);
  //printf(1,"%s\n",argv[2]);
  exec(ex[0],ex);
  exit(); 
  return 0;
}
