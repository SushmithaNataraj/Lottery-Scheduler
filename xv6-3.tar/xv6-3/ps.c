#include "types.h"
#include "stat.h"
#include "user.h"
#include "pstat.h"
//#include <time.h>
int
main(int argc, char *argv[])
{
  struct pstat pstat_ptr;
  //printf(1,"Number of tickets entered by user is %d\n",ticket);*/
  int pinfo =  getpinfo(&pstat_ptr);
  if(pinfo == -1)
  {
	printf(1,"Failed to retrieve process info\n");
	exit();
  }
  int i;
 //printf(1,"Arguments are argv[0]: %s***argv[1]:%s\n",argv[0],argv[1]);
 //printf(1,"PID Tickets Ticks\n");
 
  //clock_t start = 0;
 
  if(strcmp(argv[1],"-r") == 0){
//	start = clock();
	while(1){
		sleep(100);
		getpinfo(&pstat_ptr);
	 	printf(1,"PID Tickets Ticks\n");
	 	for(i = 0;i<64;i++){
	   	    if(pstat_ptr.inuse[i] == 1){
			printf(1, "%d, ", pstat_ptr.pid[i]);
			printf(1, "%d, ", pstat_ptr.tickets[i]);
			printf(1, "%d, \n", pstat_ptr.ticks[i]);
           	     }
         	}
	}
  }
  else{
   if(argv[1] == '\0'){
     //  start = clock();
       printf(1,"PID Tickets Ticks\n");
       for(i = 0; i<64;i++)
       {
	  if(pstat_ptr.inuse[i] == 1){
		printf(1, "%d, ", pstat_ptr.pid[i]);
		printf(1, "%d, ", pstat_ptr.tickets[i]);
		printf(1, "%d, \n", pstat_ptr.ticks[i]);
        	}
       }
   }
   else{
   	printf(1,"Please enter ps or ps -r to get process information!!\n");
   }    
  } 
 // clock_t end = clock();
 // printf(1,"Start time : %d Total time spent in execution %d \n", start, (end-start)/ CLOCKS_PER_SEC);
  exit(); 
}
